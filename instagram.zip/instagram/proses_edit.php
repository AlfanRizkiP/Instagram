<?php
include "koneksi.php";
require "function.php";
var_dump($_POST);
if (isset($_POST['update'])) {
    $no = $_POST['no'];
    $foto_lama = $_POST['foto_lama'];
    $foto_baru = $_FILES['gambar']['name'];
    $caption = $_POST['caption'];
    $lokasi = $_POST['lokasi'];

    // jika gambarnya sama, pakai foto yang lama
    if( $_FILES['gambar']['error'] === 4 ) {
		$gambar = $foto_lama;
	} else {
        $sql = "SELECT * FROM post WHERE no = '$no' ";
        $query = mysqli_query($koneksi, $sql);
    
        // menghapus foto lama karena nanti akan diganti yang baru
        while($post = mysqli_fetch_assoc($query)) {
            $gambar = $post['gambar'];
            unlink('images/' . $gambar);
        }

        // lakukan proses upload gambar baru
		$gambar = upload();
	}
    
    $sql2 = "UPDATE post SET gambar = '$gambar', caption='$caption', lokasi='$lokasi' WHERE no = '$no' ";
    $query2 = mysqli_query($koneksi, $sql2);

    if ($query2) {
        header("location:index.php?edit=sukses");
    } else {
        header("location:index.php?edit=gagal");
    }
    
}