<?php 
    include "koneksi.php";
    session_start();
    if(!isset($_SESSION['login'])){
      header("location:login.php?pesan=login dulu");
    }
    $sql = "SELECT * FROM post ORDER BY no DESC";
    $query = mysqli_query($koneksi, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <title>A̷l̷f̷a̷n̷p̷o̷s̷t̷</title>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top" style="background-color: #B4B4B3;">
  <div class="container-fluid">
    <img src="images/logo.png" style="width:60px; height:60;" class="me-2" alt="">
    <img src="images/alfan.png" style="width:70px; height:100%;" class="me-3" alt="">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <li class="nav-item">
        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa-solid fa-square-plus"></i></button>
        </li>    
</div>
<a href="logout.php"><button class="btn btn-warning text-light"><i class="fa-solid fa-right-from-bracket" style="color: #3a403a;"></i>Log out</button></a>
    </div>
  </div>
</nav><br><br>
<style>
  body{
  background-color: #E55604;
  }
  .img-hover-zoom--collorize img{
    transition: transform .5s, filter 1.5s ease-in-out;
    filter : grayscale(50%)
  }
  .img-hover-zoom--colorize:hover img{
    filter: grayscale(0);
    transform: scale(1.1);
  }
</style>
    <?php while($post=mysqli_fetch_assoc($query)){
        ?>
        <center>
        <div class="card" style="width: 30rem; backround-color: grey;">
        <div class="img-hover-zoom img-hover-zoom--colorize">
        <img src="images/<?=$post['gambar']?>" class="card-img-top" alt="...">
        </div>
  
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><?=$post['caption']?></li>
    <li class="list-group-item"><?=$post['lokasi']?></li>
  </ul>
  <div class="card-body">
    <a type="button" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $post['no']?>"><i class="fa-solid fa-pen-to-square" style="font-size:30px; color:green;"></i></a> | 
    <a href="hapus.php?no=<?=$post['no']?>" onclick="return confirm('Yakin hapus?')" class="card-link"  ><i class="fa-solid fa-trash" style="font-size:30px; color:red;"></i></a>
  </div>
</div><br><br></center>

<div class="modal fade" id="exampleModal<?= $post['no']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Postingan</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no']?>">
        <input type="hidden" name="foto_lama" value="<?= $post['gambar']?>">

        <label for="">Gambar</label><br>
        <input type="file" name="gambar" id="" value="<?= $post['gambar']?>"><br><br>
        <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br>
        <label for="">Caption</label><br>
        <input type="text" name="caption" id="" class="form-control" value="<?= $post['caption']?>" class="form-control" autocomplete="off"><br>
        <label for="">Lokasi</label><br>
        <input type="text" name="lokasi" id="" class="form-control" value="<?= $post['lokasi']?>" class="form-control" autocomplete="off"><br>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <input type="submit" value="Update" name="update" class="btn btn-warning">
      </div>
    </form>
      </div>

    </div>
  </div>
</div>

        <?php }?>
    </div>
    
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Postingan</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <div class="mb-3">
        <label for="">Gambar</label>
        <input type="file" name="gambar" id="" class="form-control" required>
        </div>
        <div class="mb-3">
        <label for="">Caption</label>
        <input type="text" name="caption" id="" class="form-control" autocomplete="off">
        </div>
        <div class="mb-3">
        <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" class="form-control" autocomplete="off">
        </div>
        <div class="modal-footer">
        <button type="submit" class="btn btn-warning" name="tambah">Tambah</button>
      </div>
    </form>
    </div>
      
    </div>
  </div>
</div>

    </body>
</html>