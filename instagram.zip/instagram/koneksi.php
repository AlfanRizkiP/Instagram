<?php
    $server = "localhost";
    $username = "root";
    $password = "123456";
    $db = "db_instagram";
    $koneksi = mysqli_connect($server, $username, $password, $db);
?>